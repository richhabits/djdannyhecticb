/**
 * Admin bootstrap script.
 *
 * SECURITY: This script intentionally has NO default credentials.
 * Provide all values via environment variables.
 *
 * Required:
 *  - DB_HOST, DB_USER, DB_PASSWORD, DB_NAME
 *  - ADMIN_EMAIL, ADMIN_PASSWORD
 * Optional:
 *  - ADMIN_NAME
 */
import bcrypt from "bcryptjs";
import mysql from "mysql2/promise";

async function required(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

async function createAdmin() {
  const host = await required("DB_HOST");
  const user = await required("DB_USER");
  const password = await required("DB_PASSWORD");
  const database = await required("DB_NAME");

  const email = await required("ADMIN_EMAIL");
  const adminPassword = await required("ADMIN_PASSWORD");
  const name = process.env.ADMIN_NAME || "Admin";

  const conn = await mysql.createConnection({ host, user, password, database });

  try {
    await conn.execute(`
      CREATE TABLE IF NOT EXISTS admin_credentials (
        id int AUTO_INCREMENT PRIMARY KEY,
        userId int NOT NULL,
        email varchar(320) NOT NULL UNIQUE,
        passwordHash varchar(255) NOT NULL,
        lastLoginAt timestamp NULL,
        failedLoginAttempts int NOT NULL DEFAULT 0,
        lockedUntil timestamp NULL,
        createdAt timestamp NOT NULL DEFAULT (now()),
        updatedAt timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP
      )
    `);

    const [existing] = await conn.execute(
      "SELECT id FROM admin_credentials WHERE email = ? LIMIT 1",
      [email]
    );

    if (Array.isArray(existing) && existing.length > 0) {
      console.log("✅ Admin already exists (email match).");
      return;
    }

    const passwordHash = await bcrypt.hash(adminPassword, 12);
    const openId = `admin-${email}-${Date.now()}`;

    // Create user
    const [userResult] = await conn.execute(
      "INSERT INTO users (openId, email, name, loginMethod, role, lastSignedIn) VALUES (?, ?, ?, ?, ?, ?)",
      [openId, email, name, "password", "admin", new Date()]
    );

    const userId = userResult.insertId;

    // Create credentials
    await conn.execute(
      "INSERT INTO admin_credentials (userId, email, passwordHash) VALUES (?, ?, ?)",
      [userId, email, passwordHash]
    );

    console.log("✅ Admin created successfully!");
    console.log(`   Email: ${email}`);
    console.log(`   User ID: ${userId}`);
    console.log("   Password: (not printed)");
  } finally {
    await conn.end();
  }
}

createAdmin().catch((err) => {
  console.error("❌ Error:", err?.message || err);
  process.exit(1);
});
