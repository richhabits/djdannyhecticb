import crypto from "crypto";

function salt(): string {
  return process.env.PRIVACY_SALT || process.env.JWT_SECRET || "change-me";
}

export function hashValue(value: string): string {
  return crypto.createHmac("sha256", salt()).update(value).digest("hex");
}

export function getClientIp(req: any): string {
  const xf = req.headers["x-forwarded-for"];
  const ip = Array.isArray(xf) ? xf[0] : (typeof xf === "string" ? xf.split(",")[0] : undefined);
  return (ip || req.socket?.remoteAddress || "").trim();
}

export function getUserAgent(req: any): string {
  return String(req.headers["user-agent"] || "");
}
